function disp(x)
%DISP         Display function for pop-up windows in debugger
%
%Displays x without header
%

% written  04/26/13     S.M. Rump
%

  display(x,[],1);