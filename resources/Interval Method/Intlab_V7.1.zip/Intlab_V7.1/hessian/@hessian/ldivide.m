function r = ldivide(a,b)
%LDIVIDE      Hessian elementwise left division  a .\ b
%

% written  11/02/05     S.M. Rump
%

  r = b ./ a;
