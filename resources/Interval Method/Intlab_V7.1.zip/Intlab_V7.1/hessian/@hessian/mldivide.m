function r = mldivide(a,b)
%MLDIVIDE     Hessian left division  a \ b
%

% written  11/02/05     S.M. Rump
%

  r = b / a;
  