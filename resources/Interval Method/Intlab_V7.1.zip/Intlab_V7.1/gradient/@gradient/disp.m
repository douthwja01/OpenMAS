function disp(x)
%DISP         Display function for pop-up windows in debugger
%

% written  04/26/13     S.M. Rump
%

  display(x);